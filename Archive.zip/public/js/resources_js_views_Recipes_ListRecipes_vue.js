"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_views_Recipes_ListRecipes_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/Recipes/ListRecipes.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/Recipes/ListRecipes.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  created: function created() {
    this.getRecipes();
  },
  data: function data() {
    return {
      snackbar: false,
      dialog: false,
      img: "",
      items: [],
      text: "",
      headers: [{
        text: "Id",
        value: "id",
        sortable: true
      }, {
        text: "Name",
        value: "name"
      }, {
        text: "Photo",
        value: "photo"
      }, {
        text: "Actions",
        value: "actions"
      }],
      optionsTable: {
        itemsPerPage: 10
      }
    };
  },
  methods: {
    activeImg: function activeImg(img) {
      this.img = img;
      this.dialog = true;
    },
    deleteRecipe: function deleteRecipe(item) {
      var _this = this;

      this.$swal({
        title: "Are you sure?",
        text: "Yes, Delete Recipe!",
        type: "warning",
        showCancelButton: true,
        confirmButtonText: "Yes, delete it!",
        cancelButtonText: "No"
      }).then(function (result) {
        if (result.value) {
          try {
            axios__WEBPACK_IMPORTED_MODULE_0___default().get("/recipe/delete/" + item).then(function () {
              var index = _this.items.findIndex(function (item) {
                return item.id == item;
              });

              _this.items.splice(index, 1);

              _this.$store.commit("SET_SNACKBAR", {
                show: true,
                text: "Recipe deleted successfully"
              });
            });
          } catch (error) {}
        }
      });
    },
    getRecipes: function getRecipes() {
      var _this2 = this;

      try {
        axios__WEBPACK_IMPORTED_MODULE_0___default().get("/nutrition").then(function (_ref) {
          var data = _ref.data;
          return _this2.items = data;
        });
      } catch (error) {
        console.log(error);
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!./node_modules/vue-loader/lib/loaders/templateLoader.js??ruleSet[1].rules[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/Recipes/ListRecipes.vue?vue&type=template&id=e26b3064&":
/*!********************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!./node_modules/vue-loader/lib/loaders/templateLoader.js??ruleSet[1].rules[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/Recipes/ListRecipes.vue?vue&type=template&id=e26b3064& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function render() {
  var _vm = this,
      _c = _vm._self._c;

  return _c("v-main", [_c("v-row", {
    staticClass: "mb-4"
  }, [_c("v-col", {
    attrs: {
      cols: "3"
    }
  }, [_c("h2", [_vm._v("Nutrition Plans")])]), _vm._v(" "), _c("v-spacer"), _vm._v(" "), _c("v-col", {
    attrs: {
      cols: "3"
    }
  }, [_c("v-btn", {
    attrs: {
      color: "primary",
      to: "/recipes/create"
    }
  }, [_vm._v("\n        Create nutrition plan\n        "), _c("v-icon", [_vm._v(" mdi-pencil ")])], 1)], 1)], 1), _vm._v(" "), _c("v-spacer"), _vm._v(" "), _c("v-data-table", {
    staticClass: "elevation-1 pt-5",
    attrs: {
      headers: _vm.headers,
      items: _vm.items,
      "items-per-page": 5,
      options: _vm.optionsTable
    },
    scopedSlots: _vm._u([{
      key: "item",
      fn: function fn(props) {
        return [_c("tr", [_c("td", [_vm._v("\n          " + _vm._s(props.item.id) + "\n        ")]), _vm._v(" "), _c("td", [_vm._v("\n          " + _vm._s(props.item.name) + "\n        ")]), _vm._v(" "), _c("td", [_c("img", {
          attrs: {
            width: "30px",
            src: props.item.photo,
            alt: ""
          },
          on: {
            click: function click($event) {
              return _vm.activeImg(props.item.photo);
            }
          }
        })]), _vm._v(" "), _c("td", [_c("v-btn", {
          attrs: {
            color: "orange",
            fab: "",
            small: "",
            dark: "",
            to: {
              name: "recipe_plan_edit",
              params: {
                id: props.item.id
              }
            }
          }
        }, [_c("v-icon", [_vm._v("mdi-pencil")])], 1), _vm._v(" "), _c("v-btn", {
          attrs: {
            color: "red",
            fab: "",
            small: "",
            dark: ""
          },
          on: {
            click: function click($event) {
              return _vm.deleteRecipe(props.item.id);
            }
          }
        }, [_c("v-icon", [_vm._v("mdi-delete")])], 1)], 1)])];
      }
    }])
  }), _vm._v(" "), _c("v-dialog", {
    attrs: {
      width: "500"
    },
    model: {
      value: _vm.dialog,
      callback: function callback($$v) {
        _vm.dialog = $$v;
      },
      expression: "dialog"
    }
  }, [_c("img", {
    attrs: {
      width: "30px",
      src: _vm.img,
      alt: ""
    }
  })]), _vm._v(" "), _c("v-snackbar", {
    scopedSlots: _vm._u([{
      key: "action",
      fn: function fn(_ref) {
        var attrs = _ref.attrs;
        return [_c("v-btn", _vm._b({
          attrs: {
            color: "pink",
            text: ""
          },
          on: {
            click: function click($event) {
              _vm.snackbar = false;
            }
          }
        }, "v-btn", attrs, false), [_vm._v("\n        Close\n      ")])];
      }
    }]),
    model: {
      value: _vm.snackbar,
      callback: function callback($$v) {
        _vm.snackbar = $$v;
      },
      expression: "snackbar"
    }
  }, [_vm._v("\n    " + _vm._s(_vm.text) + "\n\n    ")])], 1);
};

var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./resources/js/views/Recipes/ListRecipes.vue":
/*!****************************************************!*\
  !*** ./resources/js/views/Recipes/ListRecipes.vue ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _ListRecipes_vue_vue_type_template_id_e26b3064___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ListRecipes.vue?vue&type=template&id=e26b3064& */ "./resources/js/views/Recipes/ListRecipes.vue?vue&type=template&id=e26b3064&");
/* harmony import */ var _ListRecipes_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ListRecipes.vue?vue&type=script&lang=js& */ "./resources/js/views/Recipes/ListRecipes.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ListRecipes_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _ListRecipes_vue_vue_type_template_id_e26b3064___WEBPACK_IMPORTED_MODULE_0__.render,
  _ListRecipes_vue_vue_type_template_id_e26b3064___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/views/Recipes/ListRecipes.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/views/Recipes/ListRecipes.vue?vue&type=script&lang=js&":
/*!*****************************************************************************!*\
  !*** ./resources/js/views/Recipes/ListRecipes.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ListRecipes_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./ListRecipes.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/Recipes/ListRecipes.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ListRecipes_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/views/Recipes/ListRecipes.vue?vue&type=template&id=e26b3064&":
/*!***********************************************************************************!*\
  !*** ./resources/js/views/Recipes/ListRecipes.vue?vue&type=template&id=e26b3064& ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_use_0_node_modules_vue_loader_lib_loaders_templateLoader_js_ruleSet_1_rules_2_node_modules_vue_loader_lib_index_js_vue_loader_options_ListRecipes_vue_vue_type_template_id_e26b3064___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_use_0_node_modules_vue_loader_lib_loaders_templateLoader_js_ruleSet_1_rules_2_node_modules_vue_loader_lib_index_js_vue_loader_options_ListRecipes_vue_vue_type_template_id_e26b3064___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_use_0_node_modules_vue_loader_lib_loaders_templateLoader_js_ruleSet_1_rules_2_node_modules_vue_loader_lib_index_js_vue_loader_options_ListRecipes_vue_vue_type_template_id_e26b3064___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ruleSet[1].rules[2]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./ListRecipes.vue?vue&type=template&id=e26b3064& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!./node_modules/vue-loader/lib/loaders/templateLoader.js??ruleSet[1].rules[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/Recipes/ListRecipes.vue?vue&type=template&id=e26b3064&");


/***/ })

}]);