import './bootstrap'
import Vue from 'vue'
import Vuetify from 'vuetify'
import 'vuetify/dist/vuetify.min.css'
import '@mdi/font/css/materialdesignicons.css'
import '../css/app.css'
Vue.use(Vuetify)

import App from './App.vue'
import router from './routes/index'
import store from './store/index'
import axios from 'axios'
import wysiwyg from "vue-wysiwyg";

import VueSweetalert2 from 'vue-sweetalert2';

// If you don't need the styles, do not connect
import 'sweetalert2/dist/sweetalert2.min.css';

Vue.use(VueSweetalert2);

Vue.use(wysiwyg, {

    image: {
      uploadURL: "/api/v1/meals/image/add",

      dropzoneOptions: {
        acceptedFiles: "image/*",
        dictDefaultMessage: "Sube la imagen",
        headers: {Authorization: 'Bearer ' + window.localStorage.token}
      }
    }
  }
);

new Vue({
    vuetify: new Vuetify({
        cons: {
            iconfont: 'md',
        },
        theme: {
            themes: {
                light: {
                    primary: '#FFC5C5',
                    secondary: '#ffc107',
                    accent: '#ff5722',
                    error: '#f44336',
                    warning: '#673ab7',
                    info: '#009688',
                    success: '#00bcd4',
                    gold: '#FAF3DA',
                    silver: '#F4F3F3',
                    diamond: '#DAE4FA',
                    bronze: '#FFDED0',
                    greenLight: '#AEE0C2',
                    redLight: '#FFD0D0',
                    rate: '#FFBE17'
                },
            },
        },
    }),
    router,
   store,
  render: h => h(App)
}).$mount('#app')
