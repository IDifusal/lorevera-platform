<template>
  <v-app>
    <Header />
    <router-view></router-view>
  </v-app>
</template>
<script>
import Header from "./components/Header.vue";
import Swal from "sweetalert2";
export default {
  name: "App",
  components: {
    Header,
  },
  watch: {
    toast() {
      const Toast = Swal.mixin({
        toast: true,
        position: "bottom-end",
        showConfirmButton: false,
        timer: 3000,
      });

      if (this.toast.show == true) {
        Toast.fire({
          type: this.toast.type,
          title: this.toast.title,
        });
      }
    },
  },
  created() {
    let token = window.localStorage.token;
    if (token) {
      this.$store.dispatch("FETCH_USER");
    }
  },
  computed: {
    toast() {
      return this.$store.getters.getToast;
    },
  },
};
</script>
<style>
.v-main__wrap {
  padding: 2rem;
}
</style>