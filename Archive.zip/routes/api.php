<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\RecipeController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\SpaController;
use App\Http\Controllers\CardioController;
use App\Http\Controllers\ProgramController;
use App\Http\Controllers\ImageController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::post('/auth/login', [AuthController::class, 'loginUser']);
Route::get('/auth/me',[AuthController::class,'me'])->middleware('auth:sanctum');
Route::get('/migrate', function () {
    Artisan::call('migrate:fresh');
    Artisan::call('db:seed');
    Artisan::call('config:clear');
    dd('!OK');
});

Route::group(['middleware' => ['auth:sanctum']],  function() {
    Route::get('/users/',[UserController::class,'index']);
    Route::get('/dashboard/',[SpaController::class,'dashboard']);
    Route::get('/recipe/', [RecipeController::class, 'index']);
    Route::get('/recipe/{id}', [RecipeController::class, 'show']);
    Route::get('/recipe/delete/{id}', [RecipeController::class, 'destroy']);
    Route::post('/recipe/edit/',[RecipeController::class,'update']);
    Route::post('/recipe/create/',[RecipeController::class,'store']);
    Route::get('/cardio/',[CardioController::class,'index']);
    Route::post('/cardio/create',[CardioController::class,'store']);
    Route::post('/cardio/edit',[CardioController::class,'edit']);
    Route::get('/cardio/{id}',[CardioController::class,'show']);
    Route::get('/cardio/delete/{id}', [CardioController::class, 'destroy']);
    Route::get('/nutrition/', [NutritionController::class, 'index']);
    Route::get('/nutrition/{id}', [NutritionController::class, 'show']);
    Route::get('/programs/', [ProgramController::class, 'index']);
    Route::post('/programs/create', [ProgramController::class, 'store']);
    Route::get('/programs/{id}', [ProgramController::class, 'show']);
    Route::post('/uploadImage/',[ImageController::class,'store']);
});
Route::group(['prefix'=>'app'], function() {
    Route::get('/recipe/', [RecipeController::class, 'index']);
    Route::get('/programs/', [ProgramController::class, 'index']);
});

