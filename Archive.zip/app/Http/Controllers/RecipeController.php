<?php

namespace App\Http\Controllers;


use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class RecipeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data=DB::table('recipes')->where('delete','0')->orderBy('id', 'DESC')->get();
        return response()->json($data);
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name'=> 'required',
            'instructions'=> 'required'
        ]);
            $nameImg = '';
            $timestamps = Carbon::now()->timestamp;
            $name = $request->input('name');
            $nameEs = $request->input('nameEs');
            $cook_time = $request->input('cook_time');
            $calories = $request->input('calories');
            $fat = $request->input('fat');
            $carbs = $request->input('carbs');
            $protein = $request->input('protein');
            $ingredients = $request->input('ingredients');
            $ingredientsEs = $request->input('ingredientsEs');
            $categorie=$request->input('categorie');
            $preparation_time = $request->input('preparation_time');

            if($request->hasFile('image')){
                $imageName = time().'.'.$request->image->extension();  
                $path = Storage::disk('s3')->put('images', $request->image);
                $path = Storage::disk('s3')->url($path);
                $nameImg= $path;
            }
            $recipe_id = DB::table('recipes')->insertGetId([
                'name' => $name,
                'nameEs' => $nameEs,
                'instructions' => $request->input('instructions'),
                'instructionsEs' => $request->input('instructionsEs'),
                'preparation_time'=> $preparation_time,
                'cook_time'=>$cook_time,
                'calories'=>$calories,
                'fat'=>$fat,
                'carbs'=>$carbs,
                'protein'=> $protein,
                'categorie'=>$categorie,
                'ingredients'=>$ingredients,
                'ingredientsEs'=>$ingredientsEs,
                'preparation_time' => $preparation_time,
                'create_id' => $timestamps,
                'update_id' => $timestamps,
                'delete_id' => $timestamps,
                'photo'=>strlen($nameImg) > 0 ? $nameImg : '',
            ]);
            return response()->json($request);
    }

    /**
     * Display the specified resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request,$id)
    {
        $data =DB::table('recipes')->where('id',$id)->first();
        return response()->json($data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * 
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $request->validate([
            'id' => 'required',
            'name' => 'required',
            'instructions' => 'required',
        ]);
        $nameImg = '';
        try {
            $time = Carbon::now()->timestamp;
            $nameImg = $request->image;
            if($request->hasFile('image')){
                $imageName = time().'.'.$request->image->extension();  
                $path = Storage::disk('s3')->put('images', $request->image);
                $path = Storage::disk('s3')->url($path);
                $nameImg= $path;
            }
            $recipe_id = $request->input('id');
            $name = $request->input('name');
            $nameEs = $request->input('nameEs');
            $cook_time = $request->input('cook_time');
            $calories = $request->input('calories');
            $fat = $request->input('fat');
            $carbs = $request->input('carbs');
            $protein = $request->input('protein');
            $ingredients = $request->input('ingredients');
            $ingredientsEs = $request->input('ingredientsEs');
            $categorie=$request->input('categorie');
            $preparation_time = $request->input('preparation_time');

            DB::table('recipes')->where('id', $recipe_id)->update([
                'name' => $name,
                'nameEs' => $nameEs,
                'instructions' => $request->input('instructions'),
                'instructionsEs' => $request->input('instructionsEs'),
                'preparation_time'=> $preparation_time,
                'cook_time'=>$cook_time,
                'calories'=>$calories,
                'fat'=>$fat,
                'carbs'=>$carbs,
                'protein'=> $protein,
                'categorie'=>$categorie,
                'ingredients'=>$ingredients,
                'ingredientsEs'=>$ingredientsEs,
                'preparation_time' => $preparation_time,
                'update_id' => $time,
                'photo'=>$nameImg
            ]);
            return response()->json($nameImg);
        } catch (\Throwable $th) {
            throw $th;
        }
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\cr  $cr
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id )
    {
        $time = Carbon::now()->timestamp;
        DB::table('recipes')->where('id', $id)->update([
            'delete' => 1,
            'delete_id' => $time,
        ]);

        return response($id);
    }
}
