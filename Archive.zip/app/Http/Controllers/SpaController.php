<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;

class SpaController extends Controller
{
    public function index()
    {
        return view('app');
    }

    public function dashboard()
    {
        $info = DB::table('users')->count();
        $recipes = DB::table('recipes')->count();

        return response()->json(['users'=>$info,'recipes'=>$recipes]);
    }
}
