<?php

namespace App\Http\Controllers;

use App\Models\Program;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class ProgramController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //$data = DB::table('programs')->where('delete','0')->join('exercises','programs.id','=','exercises.programId')->orderBy('programs.id','DESC')->get();
        $data = DB::table('programs')->where('delete','0')->orderBy('programs.id','DESC')->get();
        return response()->json($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {        $request->validate([
        'name'=> 'required',
        'description'=> 'required'
    ]);
    try {
        $items=json_decode($request->input('items'),true);
        $nameImg = '';
        if($request->hasFile('image')){
            $imageName = time().'.'.$request->image->extension();  
            $path = Storage::disk('s3')->put('images', $request->image);
            $path = Storage::disk('s3')->url($path);
            $nameImg= $path;
        }
        $program_id=DB::table('programs')->insertGetId([
            'name'=>$request->input('name'),
            'description'=>$request->input('description'),
            'photo'=>$nameImg,
            'equipment'=>$request->input('equipment'),
        ]);

        foreach($items as $item) {
            DB::table('exercises')->insert([
                'name'=> $item['name'],
                'programId' =>$program_id,
                'duration'=> $item['time'],
                //'rest'=>$item['rest'],
                'reps'=>$item['reps'],
                'weekId'=>$item['week'],
                'video'=>$item['video']
            ]);    
        }

        //return response()->json($program_id);
        return response()->json($items);
    } catch (\Throwable $th) {
        throw $th;
    }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Program  $program
     * @return \Illuminate\Http\Response
     */
    public function show(Program $program,$id)
    {
        //$data = DB::table('programs')->where('delete','0')->join('exercises','programs.id','=','exercises.programId')->orderBy('programs.id','DESC')->get();
        $data = DB::table('programs')->where('id',$id)->first();
        $items = DB::table('exercises')->where('programId',$id)->get();
        $data->items = $items;
        return response()->json($data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Program  $program
     * @return \Illuminate\Http\Response
     */
    public function edit(Program $program)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Program  $program
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Program $program)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Program  $program
     * @return \Illuminate\Http\Response
     */
    public function destroy(Program $program)
    {
        //
    }
}
