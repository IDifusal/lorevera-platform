<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use App\Models\Cardio;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class CardioController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = Cardio::where('delete','0')->orderBy('id','DESC')->get();
        return response()->json($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $nameImg = '';
        
        try {
            $timestamps = Carbon::now()->timestamp;
            $cardio = new Cardio();
            $cardio->name = $request->name;
            $cardio->nameEs=$request->nameEs;
            $cardio->category = $request->category;
            $cardio->instructions=$request->instructions;
            $cardio->instructionsEs=$request->instructionsEs;
            $cardio->create_id = $timestamps;
            $cardio->update_id = $timestamps;
            $cardio->delete_id = $timestamps;

            if($request->hasFile('image')){
                $imageName = time().'.'.$request->image->extension();  
                $path = Storage::disk('s3')->put('images', $request->image);
                $path = Storage::disk('s3')->url($path);
                $nameImg= $path;
            }
            $cardio->image = strlen($nameImg) > 0 ? $nameImg : '';
            $cardio->save();
            return response()->json('OK');
        } catch (\Throwable $th) {
            throw $th;
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Cardio  $cardio
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request,$id)
    {
        $data = Cardio::where('id',$id)->first();
        return response()->json($data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Cardio  $cardio
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        $nameImg = '';
        
        try {
            $timestamps = Carbon::now()->timestamp;
            $nameImg = $request->image;
            if($request->hasFile('image')){
                $imageName = time().'.'.$request->image->extension();  
                $path = Storage::disk('s3')->put('images', $request->image);
                $path = Storage::disk('s3')->url($path);
                $nameImg= $path;
            }
            Cardio::whereId($request->id)->update([
                'name'=> $request->name,
                'nameEs'=>$request->nameEs,
                'category'=>$request->category,
                'instructions'=>$request->instructions,
                'instructionsEs'=>$request->instructionsEs,
                'update_id'=>$timestamps,
                'image'=>$nameImg
            ]);
            return response()->json('OK');
        } catch (\Throwable $th) {
            throw $th;
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Cardio  $cardio
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Cardio $cardio)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Cardio  $cardio
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        $time = Carbon::now()->timestamp;
            try {
                Cardio::whereId($id)->update([
                    'delete' => 1,
                    'delete_id' => $time,
                ]);
                return response('ok');
            } catch (\Throwable $th) {
                throw $th;
            }

    }
}
